# Variables, paths, consts will be initialized here

_dataDir = '/data/ttc/2018-06-29/'
_stops = 'stop_times.txt'
_trips = 'trips.txt'

